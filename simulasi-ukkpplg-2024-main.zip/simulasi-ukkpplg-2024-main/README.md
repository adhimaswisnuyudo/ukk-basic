# Simulasi UKK PPLG SMK Yadika Soreang 2024

# SOAL PRAKTIK DEMONSTRASI

https://drive.google.com/file/d/1chKftyrqriY6CRPTkIBZEotiW3qLko8j/view?usp=sharing

# PETUNJUK

- Download Zip Starterkit pada repository ini
- Kerjakan soal PRAKTIK DEMONSTRASI Aplikasi ATM di atas dengan menggunakan starterkit yang telah di download
