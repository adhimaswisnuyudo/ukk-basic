# Front-end Style Guide

## Layout

The designs were created to the following height:

- Desktop: 100vh

## Colors

### Primary

- Slate: #324154
- Bright Slate: #597298

## Typography

### Body Copy

- Font size 1 (heading): 32pt
- Font size 2 (heading): text-3xl

### Font

- Family: monospace
